from flask import Flask, render_template
app = Flask (__name__)

@app.route("/") #Criação da página de login
def login():
    return render_template('login.html')

@app.route("/home") #Criação da página principal
def homepage():
    return render_template('home.html')

@app.route("/cadastro") #Criação da página de cadastro
def cadastro():
    return render_template('cadastro.html')

@app.route("/perfil")   #Criação da página de perfil
def perfil():
    return render_template('perfil.html')

if __name__=="__main__":
    app.run(debug=True)

